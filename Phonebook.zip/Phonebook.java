import java.util.ArrayList;

public class Phonebook
{
    private ArrayList<Contact> contacts = new ArrayList<Contact>();
    
    public void addContact(Contact entry)
    {
        contacts.add(entry);
        sort();
    }
    
    public void printPhonebook()
    {
        for (Contact entry : contacts)
        {
            System.out.println(entry.getName());
        }
    }
public void sort ()
{
    for (int start = 0; start < contacts.size() - 1; start++)
    {
        int smallest = start;
        
        for (int check = start + 1; check < contacts.size(); check++)
        {
            if (contacts.get(check).getName().compareTo(contacts.get(smallest).getName()) < 0)
            {
                smallest = check;
            }
        }
         // Swap contacts at position start and smallest 
         Contact hold = contacts.get(start);
         contacts.set(start, contacts.get(smallest));
         contacts.set(smallest, hold);
    }
  }
}